var group__group__bsp__pins__btn =
[
    [ "CYBSP_USER_BTN", "group__group__bsp__pins__btn.html#ga72717d2a6e1a64352274dfb2e5649ee9", null ],
    [ "CYBSP_USER_BTN1", "group__group__bsp__pins__btn.html#ga719bfb6bb0a640a38d94febf75e45341", null ]
];