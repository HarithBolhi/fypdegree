var searchData=
[
  ['peripheral_20default_20bsp_20settings_0',['Peripheral Default BSP Settings',['../md_source_bsps_cat1a_CYSBSYSKIT_DEV_01_bsp_settings.html',1,'']]],
  ['pin_20mappings_1',['Pin Mappings',['../group__group__bsp__pins.html',1,'']]],
  ['pin_20states_2',['Pin States',['../group__group__bsp__pin__state.html',1,'']]]
];
